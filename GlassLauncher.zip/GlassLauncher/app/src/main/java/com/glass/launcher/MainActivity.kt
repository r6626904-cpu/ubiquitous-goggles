package com.glass.launcher

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Launcher() }
    }
}

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val seen = HashSet<String>()
    val out = ArrayList<AppItem>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
        for (ri in pm.queryIntentActivities(q, 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            out += AppItem(ri.loadLabel(pm).toString(), pkg, ri.loadIcon(pm).toBitmap(192, 192).asImageBitmap())
        }
    }
    return out.sortedBy { it.label.lowercase() }
}

fun loadWall(ctx: Context, s: String?): ImageBitmap? = try {
    if (s == null) null else {
        val uri = Uri.parse(s)
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = 1
        while (o.outWidth / ss > 2400) ss *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = ss }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2)?.asImageBitmap() }
    }
} catch (e: Exception) { null }

fun openApp(ctx: Context, pkg: String) {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(i)
}

@Composable
fun LiveWallpaper(wall: ImageBitmap?) {
    val inf = rememberInfiniteTransition(label = "wall")
    if (wall != null) {
        val z by inf.animateFloat(1.06f, 1.16f, infiniteRepeatable(tween(30000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "z")
        val px by inf.animateFloat(-30f, 30f, infiniteRepeatable(tween(36000, easing = LinearEasing), RepeatMode.Reverse), label = "px")
        Image(wall, null, Modifier.fillMaxSize().graphicsLayer { scaleX = z; scaleY = z; translationX = px }, contentScale = ContentScale.Crop)
    } else {
        val t by inf.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "t")
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Color(0xFF060B18))
            fun orb(c: Color, fx: Float, fy: Float, ph: Float, r: Float) {
                val ctr = Offset(size.width * (fx + 0.18f * sin(t + ph)), size.height * (fy + 0.18f * cos(t * 0.8f + ph)))
                drawCircle(Brush.radialGradient(listOf(c.copy(alpha = .75f), Color.Transparent), center = ctr, radius = r), r, ctr)
            }
            orb(Color(0xFF2A6BFF), 0.2f, 0.2f, 0f, size.width * 0.5f)
            orb(Color(0xFFC13CFF), 0.8f, 0.3f, 2f, size.width * 0.45f)
            orb(Color(0xFF10D9B0), 0.5f, 0.9f, 4f, size.width * 0.5f)
        }
    }
}

@Composable
fun Launcher() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf(listOf<AppItem>()) }
    var wall by remember { mutableStateOf<ImageBitmap?>(null) }
    var index by remember { mutableIntStateOf(0) }
    var clock by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var wm by remember { mutableIntStateOf(prefs.getInt("wm", 0)) }
    var hint by remember { mutableStateOf(true) }
    val fr = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) { loadApps(ctx) }
        wall = withContext(Dispatchers.IO) { loadWall(ctx, prefs.getString("wall", null)) }
        fr.requestFocus()
        delay(8000); hint = false
    }
    LaunchedEffect(Unit) {
        while (true) {
            clock = LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm"))
            date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d"))
            delay(10_000)
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("wall", uri.toString()).apply()
            scope.launch { wall = withContext(Dispatchers.IO) { loadWall(ctx, uri.toString()) } }
        }
    }
    BackHandler(true) {}

    val n = apps.size
    val lx by animateFloatAsState(index.toFloat(), spring(0.58f, 170f), label = "lx")
    val target = (index - 2).coerceIn(0, maxOf(0, n - 5)).toFloat()
    val sc by animateFloatAsState(target, spring(0.7f, 110f), label = "sc")
    val a = min(abs(lx - index) * 0.4f, 0.5f)

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(fr).focusable()
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionRight -> { index = min(index + 1, maxOf(0, n - 1)); true }
                    Key.DirectionLeft -> { index = maxOf(index - 1, 0); true }
                    Key.DirectionUp -> { picker.launch(arrayOf("image/*")); true }
                    Key.DirectionDown -> { prefs.edit().remove("wall").apply(); wall = null; true }
                    Key.Menu -> { wm = (wm + 1) % 3; prefs.edit().putInt("wm", wm).apply(); true }
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { apps.getOrNull(index)?.let { openApp(ctx, it.pkg) }; true }
                    else -> false
                }
            }
    ) {
        LiveWallpaper(wall)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.25f)))

        Column(Modifier.align(Alignment.TopStart).padding(start = 64.dp, top = 48.dp)) {
            if (wm < 2) Text(clock, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.ExtraLight)
            if (wm == 0) Text(date, color = Color.White.copy(.75f), fontSize = 20.sp)
        }

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val px = maxWidth / 5.4f
            val ts = px * 0.82f
            val rh = ts + 14.dp
            val gl = (maxWidth - px * 5) / 2
            val top = maxHeight * 0.56f

            apps.forEachIndexed { i, app ->
                if (abs(i - sc) > 7f) return@forEachIndexed
                val d = i - lx
                val f = 1f + 0.14f * exp(-d * d * 2.2f)
                Box(
                    Modifier.offset { IntOffset((gl + px * (i - sc)).roundToPx(), top.roundToPx()) }
                        .size(px, rh).graphicsLayer { scaleX = f; scaleY = f },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.size(ts).clip(RoundedCornerShape(28.dp))
                            .background(Color.White.copy(.1f))
                            .border(1.dp, Color.White.copy(.2f), RoundedCornerShape(28.dp)),
                        contentAlignment = Alignment.Center
                    ) { Image(app.icon, app.label, Modifier.size(ts * 0.62f)) }
                }
            }

            // Liquid glass lens: springs between apps, stretching while it moves.
            Box(
                Modifier.offset { IntOffset((gl + px * (lx - sc) + 1.dp).roundToPx(), (top + 1.dp).roundToPx()) }
                    .size(px - 2.dp, rh - 2.dp)
                    .graphicsLayer { scaleX = 1f + a; scaleY = 1f / (1f + a * 0.6f) }
                    .clip(RoundedCornerShape(36.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(.3f), Color.White.copy(.03f), Color.White.copy(.2f))))
                    .border(1.5.dp, Brush.linearGradient(listOf(Color.White.copy(.9f), Color.White.copy(.15f), Color.White.copy(.6f))), RoundedCornerShape(36.dp))
            )

            Text(apps.getOrNull(index)?.label ?: "", color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().offset(y = top + rh + 10.dp))
        }

        if (hint) Text("▲ wallpaper   ▼ reset   Menu: widgets", color = Color.White.copy(.6f), fontSize = 16.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp))
    }
}
